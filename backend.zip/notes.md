# NOTES

# 📘 Despliegue del Proyecto Reflex en AWS EC2

## 🧾 Proyecto

- **Nombre del proyecto:** `json_portfolio`
- **Framework:** [Reflex (Python)](https://reflex.dev/)
- **Propósito:** Web personal / portfolio / SPA

---

## ☁️ Infraestructura AWS

- **Servicio usado:** Amazon EC2
- **Región:** `us-east-1` (o la que usaste)
- **Instancia:** `t2.micro` (Free Tier)
- **Sistema Operativo:** Amazon Linux 2023
- **Par de claves SSH:** `web-portfolio.pem`
- **IP pública asignada:** `15.229.48.191`
- **Puertos expuestos:** `22`, `3000`

---

## 🔒 Grupo de Seguridad

| Puerto | Uso                     | Origen         |
|--------|-------------------------|----------------|
| 22     | Acceso SSH              | Mi IP (`181.x.x.x/32`) |
| 3000   | Reflex (frontend/backend) | 0.0.0.0/0 (público temporal) |

> 🔐 *Recomendado: cerrar el puerto 3000 al público en producción.*

---

## ⚙️ Pasos realizados

### 1. Conexión por SSH
```powershell
# Ir al directorio del proyecto
cd "C:\Users\USUARIO\Documents\json_portfolio"

# Quitar herencia de permisos
icacls .\web-portfolio.pem /reset
icacls .\web-portfolio.pem /inheritance:r

# Otorgar permisos de lectura al usuario actual
icacls .\web-portfolio.pem /grant:r USUARIO:R

# Verificar permisos
icacls .\web-portfolio.pem

# Conectarse a la instancia (IP actual)
ssh -i .\web-portfolio.pem ec2-user@18.231.160.175
```

### 2. Instalacion de dependencias

```
sudo yum update -y
sudo yum install -y python3.11 python3.11-devel git
```

### 3. Creacion de entorno virtual

```
python3.11 -m venv venv
source venv/bin/activate
pip install --upgrade pip
```

### 4. Instalar reflex

```
pip install reflex
```

### 5. Clonar repositorio del proyecto

```
mkdir -p ~/projects
cd ~/projects
git clone https://github.com/matiasfalconaro/json_portfolio.git
cd json_portfolio
```

### 6. Ejecutar reflex en produccion

```
reflex run --env prod --backend-host 0.0.0.0 --backend-port 3000 --frontend-port 3000
```

### 7. Acceder desde el navegador

```
http://15.229.48.191:3000
```